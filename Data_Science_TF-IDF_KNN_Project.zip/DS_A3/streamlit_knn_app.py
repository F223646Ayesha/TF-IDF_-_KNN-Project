import streamlit as st
import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder, normalize
from sklearn.metrics.pairwise import manhattan_distances, cosine_distances
from sklearn.base import BaseEstimator, ClassifierMixin
from scipy.sparse import hstack
from sklearn.feature_extraction.text import TfidfVectorizer
import ast

st.title("🧠 Disease Category Prediction using KNN")

@st.cache_data
def load_data():
    df_features = pd.read_csv("disease_features.csv")
    df_onehot = pd.read_csv("encoded_output2.csv")
    df_category_map = pd.read_csv("disease_category_mapping.csv")
    df_features = df_features.merge(df_category_map, on="Disease", how="left")

    def parse_and_join(text):
        try:
            items = ast.literal_eval(text)
            return " ".join(item.strip().lower().replace(" ", "_") for item in items if isinstance(item, str))
        except:
            return ""

    for col in ['Risk Factors', 'Symptoms', 'Signs']:
        df_features[col + '_text'] = df_features[col].apply(parse_and_join)

    tfidf = TfidfVectorizer()
    tfidf_risk = tfidf.fit_transform(df_features['Risk Factors_text'])
    tfidf_symptoms = tfidf.fit_transform(df_features['Symptoms_text'])
    tfidf_signs = tfidf.fit_transform(df_features['Signs_text'])
    tfidf_combined = normalize(hstack([tfidf_risk, tfidf_symptoms, tfidf_signs]))

    return df_features, df_onehot, tfidf_combined

df_features, df_onehot, tfidf_combined = load_data()

label_encoder = LabelEncoder()
y_encoded = label_encoder.fit_transform(df_features['Category'])

class KNNWithCustomDistance(BaseEstimator, ClassifierMixin):
    def __init__(self, k=3, metric='euclidean'):
        self.k = k
        self.metric = metric

    def fit(self, X, y):
        self.X_train = X.toarray() if hasattr(X, "toarray") else X
        self.y_train = y
        return self

    def predict(self, X, top_k=3):
        X = X.toarray() if hasattr(X, "toarray") else X
        if self.metric == 'euclidean':
            dists = np.linalg.norm(self.X_train[None, :, :] - X[:, None, :], axis=2)
        elif self.metric == 'manhattan':
            dists = manhattan_distances(X, self.X_train)
        elif self.metric == 'cosine':
            dists = cosine_distances(X, self.X_train)
        else:
            raise ValueError("Unsupported metric")
        indices = np.argsort(dists, axis=1)[:, :self.k]
        top_k_labels = self.y_train[indices]

        top_k_results = []
        for labels in top_k_labels:
            counts = np.bincount(labels, minlength=len(self.y_train))
            top_classes = counts.argsort()[::-1][:top_k]
            top_k_results.append([(label, counts[label]) for label in top_classes])
        
        return top_k_results

st.sidebar.header("🔧 Model Configuration")
encoding_type = st.sidebar.selectbox("Choose Encoding", ["TF-IDF", "One-Hot"])
k_value = st.sidebar.slider("k (number of neighbors)", min_value=1, max_value=15, step=2, value=5)
metric = st.sidebar.selectbox("Distance Metric", ["euclidean", "manhattan", "cosine"])

selected_disease = st.selectbox("Select a Disease to Predict Its Category", df_features['Disease'])
disease_index = df_features[df_features['Disease'] == selected_disease].index[0]

if encoding_type == "TF-IDF":
    X = tfidf_combined
    input_vector = tfidf_combined[disease_index]
else:
    X = df_onehot.drop(columns=["Disease"]).values
    input_vector = X[disease_index]


model = KNNWithCustomDistance(k=k_value, metric=metric)
model.fit(X, y_encoded)
top_predictions = model.predict(input_vector.reshape(1, -1))[0]
decoded_predictions = [(label_encoder.inverse_transform([label])[0], votes) for label, votes in top_predictions]

st.markdown("### 🩺 Top 3 Predicted Categories:")
for i, (category, count) in enumerate(decoded_predictions, start=1):
    st.markdown(f"**{i}. {category}** – {count} vote(s)")
